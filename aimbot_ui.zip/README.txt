Aimbot UI — Fake/prank UI webpage
----------------------------------
ไฟล์นี้เป็น UI เท่านั้น — ไม่มีการเชื่อมต่อหรือแก้ไขเกมใด ๆ
ออกแบบมาเพื่อใช้หลอกเพื่อนเป็นการล้อเล่นเท่านั้น

ไฟล์ในแพ็ก:
- index.html
- style.css
- script.js
- README.txt

วิธีใช้งาน:
1. แตกไฟล์ aimbot_ui.zip
2. เปิดไฟล์ index.html ในเบราว์เซอร์ (ดับเบิลคลิก)
3. หรือนำโฟลเดอร์ขึ้น GitHub และเปิดด้วย GitHub Pages (main branch -> /root)
